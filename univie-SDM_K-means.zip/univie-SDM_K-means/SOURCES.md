[K-Means Clustering: Example and Algorithm](http://www.dataonfocus.com/k-means-clustering-example-and-algorithm/)   
[K Means Clustering Java Code](http://www.dataonfocus.com/k-means-clustering-java-code/)  
[Hyperthreaded K-Means Implementation](http://www.javaworld.com/article/2076183/build-ci-sdlc/hyper-threaded-java.html)  
  
[k-Means: Step-By-Step Example](http://mnemstudio.org/clustering-k-means-example-1.htm)  
[k-means clustering - Wikipedia](https://en.wikipedia.org/wiki/K-means_clustering)  
